package com.droidquest.chipstuff;


public class PortSignal {
    public Signal externalSignal;
    public Signal internalSignal;
    public int type;

    public PortSignal() {
    }

}
