package com.droidquest.materials;

import java.awt.Color;

public class ChipTrash extends Material {
    public ChipTrash() {
        color = new Color(0, 128, 0);
        passable = true;
    }

}
