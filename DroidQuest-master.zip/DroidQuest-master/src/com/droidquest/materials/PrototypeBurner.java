package com.droidquest.materials;

import java.awt.Color;

public class PrototypeBurner extends Material {
    public PrototypeBurner() {
        color = Color.black;
        passable = true;
    }
}