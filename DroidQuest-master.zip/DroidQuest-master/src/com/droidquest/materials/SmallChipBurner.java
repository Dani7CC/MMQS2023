package com.droidquest.materials;

import java.awt.Color;

public class SmallChipBurner extends Material {
    public SmallChipBurner() {
        color = Color.black;
        passable = true;
    }
}
